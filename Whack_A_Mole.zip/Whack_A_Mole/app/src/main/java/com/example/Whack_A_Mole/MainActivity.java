package com.example.Whack_A_Mole;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.GridLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private TextView tvScore, tvTimer, tvLevel;
    private GridLayout gridLayout;
    private ImageButton[] buttons;  // hole buttons
    private int score = 0;
    private int level = 1;
    private int currentMoleIndex = -1;
    private Random random = new Random();
    private CountDownTimer gameTimer;
    private CountDownTimer moleTimer;
    private final int[] holesPerLevel = {4, 4, 6, 9, 9, 16};
    private final int[] moleSpeeds = {1000, 800, 600, 400, 200, 100};
    private final int[] requiredScores = {0, 15, 25, 20, 15, 10};
    private final int[] SS = {15, 25, 20, 15, 10};


    private final int gameDuration = 30000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvScore = findViewById(R.id.tvScore);
        tvTimer = findViewById(R.id.tvTimer);
        tvLevel = findViewById(R.id.tvLevel);
        gridLayout = findViewById(R.id.gridLayout);

        level = getIntent().getIntExtra("selected_level", 1);
        startLevel();

        // Back Button
        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> {
            stopTimers();
            Intent intent = new Intent(MainActivity.this, LevelSelectionActivity.class);
            startActivity(intent);
            finish();
        });

        // Pause Button
        ImageButton btnPause = findViewById(R.id.btnPause);
        btnPause.setOnClickListener(v -> showPauseDialog());

        // About Button (Pauses the game too)
        ImageButton btnAbout = findViewById(R.id.btnAbout);
        btnAbout.setOnClickListener(v -> {
            pauseTimersOnly();
            showHowToPlayDialog();
        });
    }

    private void startLevel() {
        tvLevel.setText("" + level);
        tvScore.setText("" + score);

        if (level <= SS.length) {
            int scoreToUnlockNext = SS[level - 1];
            new AlertDialog.Builder(this)
                    .setTitle("Level " + level)
                    .setMessage("You need to score " + scoreToUnlockNext + " points to unlock Level " + (level + 1) + ".\n\nReady to start?")
                    .setPositiveButton("Start", (dialog, which) -> {
                        int holes = holesPerLevel[level - 1];
                        int moleSpeed = moleSpeeds[level - 1];
                        buildGrid(holes);
                        startMoleTimer(moleSpeed);
                        startGameTimer();
                    })
                    .setCancelable(false)
                    .show();
        } else {
            // Final level
            new AlertDialog.Builder(this)
                    .setTitle("Final Level " + level)
                    .setMessage("This is the final level!\nGive it your best shot!")
                    .setPositiveButton("Start", (dialog, which) -> {
                        int holes = holesPerLevel[level - 1];
                        int moleSpeed = moleSpeeds[level - 1];
                        buildGrid(holes);
                        startMoleTimer(moleSpeed);
                        startGameTimer();
                    })
                    .setCancelable(false)
                    .show();
        }
    }




    private void buildGrid(int holes) {
        gridLayout.removeAllViews();
        int columns = (int) Math.ceil(Math.sqrt(holes));
        gridLayout.setColumnCount(columns);
        buttons = new ImageButton[holes];

        for (int i = 0; i < holes; i++) {
            ImageButton btn = new ImageButton(this);
            btn.setBackgroundResource(R.drawable.hole);  // hole image
            btn.setScaleType(ImageButton.ScaleType.FIT_CENTER);
            btn.setAdjustViewBounds(true);
            btn.setLayoutParams(new ViewGroup.LayoutParams(200, 200));
            btn.setImageDrawable(null);  // no mole initially
            btn.setPadding(0, 0, 0, 0);  // reset padding

            final int index = i;
            btn.setOnClickListener(v -> {
                if (index == currentMoleIndex) {
                    score++;
                    tvScore.setText("" + score);
                    removeMole();
                }
            });

            buttons[i] = btn;
            gridLayout.addView(btn);
        }
    }

    private void startMoleTimer(int speed) {
        moleTimer = new CountDownTimer(gameDuration, speed) {
            @Override
            public void onTick(long millisUntilFinished) {
                showRandomMole();
            }

            @Override
            public void onFinish() {}
        }.start();
    }

    private void startGameTimer() {
        gameTimer = new CountDownTimer(gameDuration, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                tvTimer.setText("" + millisUntilFinished / 1000);
            }

            @Override
            public void onFinish() {
                stopMoleTimer();
                showEndDialog();
            }
        }.start();
    }

    private void showRandomMole() {
        removeMole();
        if (buttons.length == 0) return;
        currentMoleIndex = random.nextInt(buttons.length);
        ImageButton btn = buttons[currentMoleIndex];

        btn.setImageResource(R.drawable.mole1);  // mole appears

        // Make mole image larger inside fixed button size
        btn.setScaleType(ImageButton.ScaleType.CENTER_INSIDE);

        // Negative padding to "zoom" mole image inside the hole button (adjust -30 as needed)
        int padding = -60;
        btn.setPadding(padding, padding, padding, padding);
    }

    private void removeMole() {
        if (currentMoleIndex != -1) {
            ImageButton btn = buttons[currentMoleIndex];
            btn.setImageDrawable(null);  // mole disappears
            btn.setPadding(0, 0, 0, 0);  // reset padding to default
            currentMoleIndex = -1;
        }
    }

    private void stopMoleTimer() {
        if (moleTimer != null) moleTimer.cancel();
    }

    private void stopTimers() {
        if (moleTimer != null) moleTimer.cancel();
        if (gameTimer != null) gameTimer.cancel();
    }

    private void pauseTimersOnly() {
        stopMoleTimer();
        if (gameTimer != null) gameTimer.cancel();
    }

    private void showPauseDialog() {
        pauseTimersOnly();
        new AlertDialog.Builder(this)
                .setTitle("Game Paused")
                .setMessage("Do you want to continue?")
                .setPositiveButton("Resume", (dialog, which) -> {
                    startGameTimer();
                    startMoleTimer(moleSpeeds[level - 1]);
                })
                .setNegativeButton("Back to Levels", (dialog, which) -> {
                    Intent intent = new Intent(MainActivity.this, LevelSelectionActivity.class);
                    startActivity(intent);
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    private void showEndDialog() {
        boolean passed = score >= requiredScores[level];

        if (passed) saveUnlockedLevel();

        new AlertDialog.Builder(this)
                .setTitle(passed ? "Level Passed!" : "Level Failed")
                .setMessage("Score: " + score + (passed ? "\nProceed to next level?" : "\nRetry this level?"))
                .setPositiveButton(passed ? "Next" : "Retry", (dialog, which) -> {
                    if (passed) {
                        Intent intent = new Intent(MainActivity.this, LevelSelectionActivity.class);
                        startActivity(intent);
                    } else {
                        recreate();
                    }
                })
                .setNegativeButton("Back to Levels", (dialog, which) -> {
                    Intent intent = new Intent(MainActivity.this, LevelSelectionActivity.class);
                    startActivity(intent);
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    private void saveUnlockedLevel() {
        SharedPreferences prefs = getSharedPreferences("whackamole", MODE_PRIVATE);
        int unlocked = prefs.getInt("unlocked_level", 1);
        if (level >= unlocked) {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt("unlocked_level", level + 1);
            editor.apply();
        }
    }

    private void showHowToPlayDialog() {
        new AlertDialog.Builder(this)
                .setTitle("How to Play")
                .setMessage("Tap the mole (🐹) as fast as you can before it disappears!\n\n" +
                        "- Your goal is to reach the target score within 30 seconds.\n" +
                        "- The number of holes and mole speed increases with each level.\n" +
                        "- Score enough points to unlock the next level.\n\n" +
                        "Good luck and have fun!")
                .setPositiveButton("Got it!", (dialog, which) -> {
                    startGameTimer();
                    startMoleTimer(moleSpeeds[level - 1]);
                })
                .setCancelable(false)
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopTimers();
    }
}
