package com.example.Whack_A_Mole;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class LevelSelectionActivity extends AppCompatActivity {
    private Button[] levelButtons = new Button[6];
    private ImageView[] lockImages = new ImageView[6]; // lock image references

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level_selection);

        // Initialize back button
        ImageButton btnBack = findViewById(R.id.btnBack1);
        ImageButton btnAbout = findViewById(R.id.btnAbout);
        btnAbout.setOnClickListener(v -> showAboutDialog());

        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(LevelSelectionActivity.this, StartActivity.class);
            startActivity(intent);
            finish(); // optional to prevent returning with the back button
        });

        // Initialize level buttons
        levelButtons[0] = findViewById(R.id.btnLevel1);
        levelButtons[1] = findViewById(R.id.btnLevel2);
        levelButtons[2] = findViewById(R.id.btnLevel3);
        levelButtons[3] = findViewById(R.id.btnLevel4);
        levelButtons[4] = findViewById(R.id.btnLevel5);
        levelButtons[5] = findViewById(R.id.btnLevel6);

        // Initialize lock image references
        lockImages[0] = null; // Level 1 has no lock
        lockImages[1] = findViewById(R.id.lockLevel2);
        lockImages[2] = findViewById(R.id.lockLevel3);
        lockImages[3] = findViewById(R.id.lockLevel4);
        lockImages[4] = findViewById(R.id.lockLevel5);
        lockImages[5] = findViewById(R.id.lockLevel6);

        // Load unlocked level from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("whackamole", MODE_PRIVATE);
        int unlockedLevel = prefs.getInt("unlocked_level", 1); // default unlocked is Level 1

        // Set level buttons and locks
        for (int i = 0; i < levelButtons.length; i++) {
            int levelIndex = i + 1;
            boolean isUnlocked = levelIndex <= unlockedLevel;

            levelButtons[i].setEnabled(isUnlocked);
            if (isUnlocked && lockImages[i] != null) {
                lockImages[i].setVisibility(ImageView.GONE);
            }

            final int finalLevel = levelIndex; // for lambda
            levelButtons[i].setOnClickListener(v -> launchLevel(finalLevel));
        }
    }


    private void launchLevel(int level) {
        Intent intent = new Intent(LevelSelectionActivity.this, MainActivity.class);
        intent.putExtra("selected_level", level);
        startActivity(intent);
        finish();
    }

    private void showAboutDialog() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("About")
                .setTitle("How to Play")
                .setMessage("Tap the mole (🐹) as fast as you can before it disappears!\n\n" +
                        "- Your goal is to reach the target score within 30 seconds.\n" +
                        "- The number of holes and mole speed increases with each level.\n" +
                        "- Score enough points to unlock the next level.\n\n" +
                        "Good luck and have fun!")
                .setPositiveButton("Got it!", null)
                .show();
    }



}
